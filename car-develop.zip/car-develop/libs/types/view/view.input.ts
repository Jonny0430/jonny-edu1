import { ViewGroup } from '../../enums/view.enum';

export interface ViewInput {
	memberId: string;
	viewRefId: string;
	viewGroup: ViewGroup;
}
