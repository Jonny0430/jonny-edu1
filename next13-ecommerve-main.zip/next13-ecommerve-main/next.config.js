/** @type {import('next').NextConfig} */
const nextConfig = {
	images: {
		domains: ['fakestoreapi.com'],
	},
};

module.exports = nextConfig;
