export type EndpointTypes = 'mainnet' | 'devnet' | 'localnet'
