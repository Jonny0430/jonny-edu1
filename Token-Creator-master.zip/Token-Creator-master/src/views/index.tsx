export { HomeView } from "./home";
export { MetadataView } from './metadata';
export { UploaderView } from './uploader';
export { BasicsView } from "./basics";
export { UpdateView } from "./update";
