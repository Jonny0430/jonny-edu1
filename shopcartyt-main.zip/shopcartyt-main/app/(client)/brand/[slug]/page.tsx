import React from "react";

const BrandPage = () => {
  return <div>BrandPage</div>;
};

export default BrandPage;
