import paypalLogo from "./paypalLogo.png";
import emptyCart from "./emptyCart.png";
import banner_1 from "./banner/banner_1.png";
export { paypalLogo, emptyCart, banner_1 };
